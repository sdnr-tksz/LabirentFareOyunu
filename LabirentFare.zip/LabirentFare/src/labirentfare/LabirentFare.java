package labirentfare;

import javax.swing.JOptionPane;

public class LabirentFare {
    // 2 ler labirent duvarı, 0 lar ise yol
    private int labirent[][] = {
        {2, 2, 2, 2, 2, 2, 2, 2, 2, 2},
        {0, 0, 0, 0, 2, 0, 0, 0, 0, 2},
        {2, 2, 2, 0, 2, 0, 2, 2, 0, 2},
        {2, 0, 0, 0, 2, 0, 0, 2, 0, 2},
        {2, 0, 0, 0, 0, 0, 2, 2, 0, 2},
        {2, 0, 2, 2, 2, 0, 0, 2, 2, 2},
        {2, 0, 0, 0, 0, 0, 2, 0, 0, 2},
        {2, 2, 0, 2, 2, 2, 2, 0, 0, 2},
        {2, 0, 0, 0, 0, 0, 0, 0, 0, 2},
        {2, 2, 2, 2, 2, 2, 2, 2, 2, 2}
    };
    
    // java swing haraket tusşarı 
    int oyunSatir = 1, oyunSutun = 0;
    Object etk[] = {"Sola", "Sağa", "Yukarı", "Aşağı", "ÇIKIŞ"};
    
    
    // labirent dizisi java swing in html okuma özelliği ile oyun arayüzüne dönüşür
    public String labirentAl() {
        String ekran = "<html><table>";
        for (int satir = 0; satir < labirent.length; satir++) {
            ekran += "<tr>";
            for (int sutun = 0; sutun < labirent[satir].length; sutun++) {
                //duvarların rengi sarı
                if (labirent[satir][sutun] == 2) 
                    ekran += "<td bgcolor='yellow' width =25></td>";
                // yollar beyaz
                 else if (labirent[satir][sutun] == 0) 
                    ekran += "<td bgcolor='white' width =25></td>";
                 // fare ise mavi renk
                 else 
                    ekran += "<td bgcolor='blue' width =25></td>";
                
            }
            ekran += "</tr>";
        }
        ekran += "</html></table>";

        return ekran;
    }

    public void oyunBasla() {
        // oyunun başlangıc noktası
        labirent[oyunSatir][oyunSutun] = -1;
        int oyunSecim;
        
        while (labirent[9][8] != -1) {
            oyunSecim = JOptionPane.showOptionDialog(null, labirentAl(), "Labirent",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, etk, etk[4]);
            labirent[oyunSatir][oyunSutun] = 0;
            switch (oyunSecim) {
                case 0:
                    solaGit();
                    break;
                case 1:
                    sağaGit();
                    break;
                case 2:
                    yukariGit();
                    break;
                case 3:
                    asagiGit();
                    break;
                case 4:
                    System.exit(0);
                    break;
            }
            labirent[oyunSatir][oyunSutun] = -1;           
        }
        
        JOptionPane.showMessageDialog(null, "OYUN BİTTİ");
    }
    // switch içerisindeki metodlar
    public void solaGit() {
        oyunSutun--;
        if (oyunSutun == -1 || labirent[oyunSatir][oyunSutun] == 2) {
            oyunSutun++;
        }
    }

    public void sağaGit() {
        oyunSutun++;
        if (oyunSutun == labirent[oyunSatir].length || labirent[oyunSatir][oyunSutun] == 2) {
            oyunSutun--;
        }
    }

    public void yukariGit() {
        oyunSatir--;
        if (oyunSutun == -1 || labirent[oyunSatir][oyunSutun] == 2) {
            oyunSutun++;
        }
    }

    public void asagiGit() {
        oyunSatir++;
        if (oyunSutun == labirent.length || labirent[oyunSatir][oyunSutun] == 2) {
            oyunSutun--;
        }
    }

    public static void main(String[] args) {
        LabirentFare lab =new LabirentFare();
        lab.oyunBasla();
    }
}
